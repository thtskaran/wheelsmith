# sanskritayam/__main__.py
from .wheelsmith import main

if __name__ == "__main__":
    main()